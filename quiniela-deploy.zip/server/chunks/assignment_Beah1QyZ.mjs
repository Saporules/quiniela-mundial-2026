import { l as getAssignments, p as getParticipants, c as clearAssignments, t as insertTeamAssignment, w as updateQuinielaStatus, n as getClaims } from './db_0HgGX7eu.mjs';

const TEAM_INFO = {
  // Favoritos
  ARG: { fifaRank: 1, winProb: "14%", summary: "Campeón vigente de Qatar 2022. La generación post-Messi, liderada por Álvarez, Mac Allister y Di María, llega con hambre de bicampeonato." },
  ESP: { fifaRank: 2, winProb: "12%", summary: "Campeones de la Eurocopa 2024. Yamal y Nico Williams representan la nueva generación dorada; juegan el mejor fútbol del mundo." },
  FRA: { fifaRank: 3, winProb: "11%", summary: "Finalistas en 2022. Mbappé en su plenitud, con plantilla profunda y talento de clase mundial en cada línea." },
  BRA: { fifaRank: 5, winProb: "10%", summary: "Cinco veces campeones buscando redención. Vinicius Jr. y Rodrygo lideran una carga ofensiva que puede hacer historia." },
  ENG: { fifaRank: 4, winProb: "9%", summary: "Finalistas en 2021 y semifinalistas en 2018 y 2022. Bellingham, Saka y Foden forman uno de los mejores ataques del torneo." },
  GER: { fifaRank: 6, winProb: "8%", summary: "Cuatro veces campeones con hambre de más. Kimmich y Wirtz lideran una renovación que mostró su nivel en casa durante la Euro 2024." },
  POR: { fifaRank: 7, winProb: "6%", summary: "La era post-Ronaldo en plena construcción. Bruno Fernandes y Bernardo Silva llevan la batuta de un equipo con talento de sobra." },
  NED: { fifaRank: 8, winProb: "5%", summary: "Semifinalistas en 2022. Van Dijk y Gakpo encabezan un equipo sólido que nunca ha ganado el Mundial pero siempre compite." },
  // Creyentes
  COL: { fifaRank: 9, winProb: "3%", summary: "Finalistas Copa América 2024 invictos. James Rodríguez sigue siendo el motor de una selección que llega en su mejor momento histórico." },
  CRO: { fifaRank: 11, winProb: "2%", summary: "Subcampeones en 2018, terceros en 2022. Modric en su probable último Mundial; su experiencia puede marcar la diferencia." },
  HUN: { fifaRank: 26, winProb: "0.2%", summary: "Primera Copa del Mundo en 40 años. Dominik Szoboszlai lidera una generación húngara con sed de revancha histórica y calidad técnica real." },
  URU: { fifaRank: 16, winProb: "2%", summary: "Doble campeón histórico. Núñez y Valverde conforman una generación con calidad real para dar sorpresas en cualquier instancia." },
  USA: { fifaRank: 13, winProb: "2%", summary: "Coanfitriones en plena explosión futbolística. Pulisic, McKennie y Reyna lideran ante millones de locales en los estadios más grandes." },
  MAR: { fifaRank: 10, winProb: "1.5%", summary: "La revelación de Qatar 2022 llegando a semifinales. En-Nesyri y Hakimi buscan repetir y superar la hazaña que sacudió al mundo árabe." },
  JPN: { fifaRank: 15, winProb: "1%", summary: "Eliminaron a Alemania y España en Qatar 2022. Disciplinados, intensos y capaces de sorprender a cualquier rival en fase de grupos." },
  BEL: { fifaRank: 22, winProb: "1%", summary: "Generación dorada en declive pero aún peligrosa. De Bruyne y Tielemans se juegan su última gran oportunidad mundialista." },
  DEN: { fifaRank: 18, winProb: "0.8%", summary: "Sólida y difícil de vencer. Eriksen y Hojbjerg construyen juego para un equipo compacto que suele sobrevivir la fase de grupos con solvencia." },
  SUI: { fifaRank: 19, winProb: "0.7%", summary: "Los suizos siempre sorprenden. Xhaka es el motor de un equipo hábil para los octavos, aunque raramente va más lejos." },
  MEX: { fifaRank: 14, winProb: "0.5%", summary: "Coanfitrión con el peso del maleficio del quinto partido. Busca romper la barrera de octavos ante su propia afición en un Mundial histórico." },
  SEN: { fifaRank: 17, winProb: "0.5%", summary: "Campeones de África en 2022. Mendy y Diatta lideran la selección más temida del continente; capaces de llegar a cuartos de final." },
  KOR: { fifaRank: 20, winProb: "0.4%", summary: "Semifinalistas en 2002 en casa. Son Heung-min, en su probable última Copa del Mundo, puede ser el factor diferencial para avanzar." },
  TUR: { fifaRank: 25, winProb: "0.4%", summary: "Terceros en 2002 y en alza reciente. Demiral y Calhanoglu encabezan un equipo con potencial para sorprender en la fase de grupos." },
  CAN: { fifaRank: 29, winProb: "0.3%", summary: "Segunda Copa del Mundo consecutiva tras 36 años de ausencia. Davies y David construyen la era dorada del fútbol canadiense." },
  ECU: { fifaRank: 44, winProb: "0.2%", summary: "Dos mundiales seguidos con carácter y orden. Caicedo y Preciado representan la nueva ola ecuatoriana que juega sin complejos." },
  // Maletas
  AUT: { fifaRank: 24, winProb: "0.4%", summary: "Nunca pasaron de cuartos de final. Gregoritsch y Sabitzer llevan el peso ofensivo de una selección que llegó a su mejor nivel en años." },
  SRB: { fifaRank: 26, winProb: "0.3%", summary: "Llenos de talento con Vlahovic y Milinkovic-Savic, pero históricamente inconsistentes. El potencial individual supera al colectivo." },
  NGA: { fifaRank: 33, winProb: "0.3%", summary: "Las Súper Águilas siempre sorprenden. Osimhen en máxima forma es capaz de meterlos en octavos con un par de actuaciones estelares." },
  IRN: { fifaRank: 21, winProb: "0.3%", summary: "El más fuerte de Asia. Taremi lidera un equipo organizado, físico y difícil de golear que puede dar más de un susto." },
  AUS: { fifaRank: 23, winProb: "0.2%", summary: "Los Socceroos tienen tradición mundialista. Leckie y Ryan mantienen el nivel para competir en la fase de grupos con opciones reales." },
  CIV: { fifaRank: 46, winProb: "0.2%", summary: "Campeones de África en 2024. Haller busca liderar una generación de Costa de Marfil que quiere dejar por primera vez huella mundialista." },
  VEN: { fifaRank: 47, winProb: "0.2%", summary: "Primera Copa del Mundo en la historia de Venezuela. Soteldo y Bello representan un hito histórico para el fútbol del país." },
  ALG: { fifaRank: 34, winProb: "0.1%", summary: "Campeones de África en 2019. Mahrez en el ocaso pero aún decisivo para los Zorros del Desierto en su regreso a un Mundial." },
  EGY: { fifaRank: 38, winProb: "0.1%", summary: "Mo Salah puede ser el factor diferencial que lleve a Egipto más allá de la fase de grupos en su retorno a la Copa del Mundo." },
  POL: { fifaRank: 27, winProb: "0.1%", summary: "Lewandowski ya en el ocaso pero todavía peligroso. Sin el goleador en su mejor versión, Polonia depende de un colectivo sólido." },
  CMR: { fifaRank: 41, winProb: "0.1%", summary: "Los Leones Indomables siempre aparecen en mundiales. Dependen de talento disperso en ligas europeas para hacer algo interesante." },
  SCO: { fifaRank: 31, winProb: "0.1%", summary: "Primer Mundial desde 1998. Robertson lidera a una Escocia emocionada, solidaria y con poco margen para soñar en grande." },
  KSA: { fifaRank: 53, winProb: "0.05%", summary: "Ganaron a Argentina en Qatar 2022. Con la inyección del dinero de la Saudi Pro League, buscan repetir la sorpresa de su vida." },
  PAN: { fifaRank: 48, winProb: "0.05%", summary: "Segunda Copa del Mundo en su historia. El logro de clasificar ya es el objetivo cumplido; avanzar sería un milagro bienvenido." },
  CRC: { fifaRank: 54, winProb: "0.05%", summary: "Cuartos de final en 2014 fue su cima histórica. Sin la magia de aquella generación, sobrevivir en la fase de grupos ya sería un éxito." },
  MLI: { fifaRank: 52, winProb: "0.05%", summary: "Sorpresa en ascenso del fútbol africano. Camara y Doumbia construyen una identidad propia con potencial para el futuro." },
  COD: { fifaRank: 57, winProb: "0.05%", summary: "El gigante dormido del fútbol africano. Talento hay, pero la irregularidad histórica les impide consolidarse como fuerza mundial." },
  HON: { fifaRank: 78, winProb: "0.05%", summary: "Sorpresa de la CONCACAF en la clasificación. Sin figuras reconocidas, dependen del colectivo y la organización para no ir goleados." },
  IRQ: { fifaRank: 63, winProb: "0.03%", summary: "Histórico del fútbol asiático que clasificó con mérito. El salto al nivel mundialista representa el desafío más grande de su historia." },
  QAT: { fifaRank: 62, winProb: "0.03%", summary: "Organizadores en 2022 que no ganaron ningún partido. Sin la ventaja de local, el desafío de competir en el Mundial es aún mayor." },
  RSA: { fifaRank: 58, winProb: "0.03%", summary: "Organizadores en 2010, jugadores en 2026. Percy Tau busca ser el catalizador de un Bafana Bafana con más corazón que recursos." },
  JOR: { fifaRank: 88, winProb: "0.02%", summary: "Primera clasificación mundialista de Jordania. El orgullo histórico de estar aquí supera cualquier expectativa de resultado." },
  NZL: { fifaRank: 97, winProb: "0.02%", summary: "Habituales del repechaje que llegaron al torneo. Wood puede marcar algún gol memorable, pero la profundidad de plantilla es limitada." },
  IDN: { fifaRank: 125, winProb: "0.01%", summary: "Primera Copa del Mundo del país con más seguidores de fútbol sin haber clasificado antes. Un debut histórico sin importar los resultados." }
};
const TEAMS = [
  // ── FAVORITOS (8) ────────────────────────────────────────────────────────
  { code: "ARG", name: "Argentina", flag: "🇦🇷", confederation: "CONMEBOL", tier: "favorito" },
  { code: "FRA", name: "Francia", flag: "🇫🇷", confederation: "UEFA", tier: "favorito" },
  { code: "ENG", name: "Inglaterra", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", confederation: "UEFA", tier: "favorito" },
  { code: "BRA", name: "Brasil", flag: "🇧🇷", confederation: "CONMEBOL", tier: "favorito" },
  { code: "ESP", name: "España", flag: "🇪🇸", confederation: "UEFA", tier: "favorito" },
  { code: "GER", name: "Alemania", flag: "🇩🇪", confederation: "UEFA", tier: "favorito" },
  { code: "POR", name: "Portugal", flag: "🇵🇹", confederation: "UEFA", tier: "favorito" },
  { code: "NED", name: "Países Bajos", flag: "🇳🇱", confederation: "UEFA", tier: "favorito" },
  // ── CREYENTES (16) ───────────────────────────────────────────────────────
  { code: "URU", name: "Uruguay", flag: "🇺🇾", confederation: "CONMEBOL", tier: "creyente" },
  { code: "COL", name: "Colombia", flag: "🇨🇴", confederation: "CONMEBOL", tier: "creyente" },
  { code: "USA", name: "Estados Unidos", flag: "🇺🇸", confederation: "CONCACAF", tier: "creyente" },
  { code: "MEX", name: "México", flag: "🇲🇽", confederation: "CONCACAF", tier: "creyente" },
  { code: "MAR", name: "Marruecos", flag: "🇲🇦", confederation: "CAF", tier: "creyente" },
  { code: "JPN", name: "Japón", flag: "🇯🇵", confederation: "AFC", tier: "creyente" },
  { code: "CRO", name: "Croacia", flag: "🇭🇷", confederation: "UEFA", tier: "creyente" },
  { code: "HUN", name: "Hungría", flag: "🇭🇺", confederation: "UEFA", tier: "creyente" },
  { code: "DEN", name: "Dinamarca", flag: "🇩🇰", confederation: "UEFA", tier: "creyente" },
  { code: "BEL", name: "Bélgica", flag: "🇧🇪", confederation: "UEFA", tier: "creyente" },
  { code: "CAN", name: "Canadá", flag: "🇨🇦", confederation: "CONCACAF", tier: "creyente" },
  { code: "SEN", name: "Senegal", flag: "🇸🇳", confederation: "CAF", tier: "creyente" },
  { code: "SUI", name: "Suiza", flag: "🇨🇭", confederation: "UEFA", tier: "creyente" },
  { code: "KOR", name: "Corea del Sur", flag: "🇰🇷", confederation: "AFC", tier: "creyente" },
  { code: "TUR", name: "Turquía", flag: "🇹🇷", confederation: "UEFA", tier: "creyente" },
  { code: "ECU", name: "Ecuador", flag: "🇪🇨", confederation: "CONMEBOL", tier: "creyente" },
  // ── MALETAS (24) ─────────────────────────────────────────────────────────
  { code: "AUT", name: "Austria", flag: "🇦🇹", confederation: "UEFA", tier: "maleta" },
  { code: "SRB", name: "Serbia", flag: "🇷🇸", confederation: "UEFA", tier: "maleta" },
  { code: "POL", name: "Polonia", flag: "🇵🇱", confederation: "UEFA", tier: "maleta" },
  { code: "SCO", name: "Escocia", flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿", confederation: "UEFA", tier: "maleta" },
  { code: "PAN", name: "Panamá", flag: "🇵🇦", confederation: "CONCACAF", tier: "maleta" },
  { code: "HON", name: "Honduras", flag: "🇭🇳", confederation: "CONCACAF", tier: "maleta" },
  { code: "CRC", name: "Costa Rica", flag: "🇨🇷", confederation: "CONCACAF", tier: "maleta" },
  { code: "NGA", name: "Nigeria", flag: "🇳🇬", confederation: "CAF", tier: "maleta" },
  { code: "EGY", name: "Egipto", flag: "🇪🇬", confederation: "CAF", tier: "maleta" },
  { code: "CMR", name: "Camerún", flag: "🇨🇲", confederation: "CAF", tier: "maleta" },
  { code: "CIV", name: "Costa de Marfil", flag: "🇨🇮", confederation: "CAF", tier: "maleta" },
  { code: "MLI", name: "Mali", flag: "🇲🇱", confederation: "CAF", tier: "maleta" },
  { code: "COD", name: "Congo DR", flag: "🇨🇩", confederation: "CAF", tier: "maleta" },
  { code: "RSA", name: "Sudáfrica", flag: "🇿🇦", confederation: "CAF", tier: "maleta" },
  { code: "ALG", name: "Argelia", flag: "🇩🇿", confederation: "CAF", tier: "maleta" },
  { code: "IRN", name: "Irán", flag: "🇮🇷", confederation: "AFC", tier: "maleta" },
  { code: "KSA", name: "Arabia Saudita", flag: "🇸🇦", confederation: "AFC", tier: "maleta" },
  { code: "AUS", name: "Australia", flag: "🇦🇺", confederation: "AFC", tier: "maleta" },
  { code: "JOR", name: "Jordania", flag: "🇯🇴", confederation: "AFC", tier: "maleta" },
  { code: "IRQ", name: "Irak", flag: "🇮🇶", confederation: "AFC", tier: "maleta" },
  { code: "QAT", name: "Qatar", flag: "🇶🇦", confederation: "AFC", tier: "maleta" },
  { code: "NZL", name: "Nueva Zelanda", flag: "🇳🇿", confederation: "OFC", tier: "maleta" },
  { code: "VEN", name: "Venezuela", flag: "🇻🇪", confederation: "CONMEBOL", tier: "maleta" },
  { code: "IDN", name: "Indonesia", flag: "🇮🇩", confederation: "AFC", tier: "maleta" }
];
const TEAM_MAP = new Map(TEAMS.map((t) => [t.code, t]));
function getTeamsByTier(tier) {
  return TEAMS.filter((t) => t.tier === tier);
}
function getTeam(code) {
  return TEAM_MAP.get(code);
}
const TIER_CONFIG = {
  favorito: { label: "Favoritos", icon: "ph-fill ph-star", color: "wc-gold", extraPrice: 150 },
  creyente: { label: "Creyentes", icon: "ph-fill ph-fire", color: "blue-400", extraPrice: 100 },
  maleta: { label: "Maletas", icon: "ph ph-briefcase", color: "wc-muted", extraPrice: 50 }
};
const WC2026_GROUPS = {
  A: ["USA", "PAN", "ALG", "IRN"],
  B: ["MEX", "HON", "NGA", "KSA"],
  C: ["CAN", "CRC", "MAR", "BEL"],
  D: ["ARG", "ECU", "HUN", "NZL"],
  E: ["FRA", "POL", "COL", "VEN"],
  F: ["ESP", "TUR", "SEN", "KOR"],
  G: ["GER", "SCO", "JPN", "COD"],
  H: ["POR", "AUT", "CMR", "IDN"],
  I: ["ENG", "SRB", "CIV", "IRQ"],
  J: ["NED", "DEN", "EGY", "QAT"],
  K: ["BRA", "URU", "SUI", "AUS"],
  L: ["CRO", "RSA", "MLI", "JOR"]
};

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const arr2 = new Uint32Array(1);
    crypto.getRandomValues(arr2);
    const j = arr2[0] % (i + 1);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function assignTeams(quinielaId) {
  const participants = await getParticipants(quinielaId);
  const N = participants.length;
  if (N === 0) throw new Error("No hay participantes en la quiniela");
  await clearAssignments(quinielaId);
  const tiers = ["favorito", "creyente", "maleta"];
  const leftover = [];
  let assigned = 0;
  for (const tier of tiers) {
    const tierTeams = shuffleArray(getTeamsByTier(tier));
    const perPerson = Math.floor(tierTeams.length / N);
    for (let idx = 0; idx < tierTeams.length; idx++) {
      const team = tierTeams[idx];
      if (idx < perPerson * N) {
        const participant = participants[idx % N];
        await insertTeamAssignment({ quinielaId, participantId: participant.id, teamCode: team.code, assignmentType: "random", sharePercentage: 100, extraPaid: 0 });
        assigned++;
      } else {
        leftover.push(team.code);
      }
    }
  }
  await updateQuinielaStatus(quinielaId, "draft");
  return { assigned, leftover };
}
async function resolveClaims(quinielaId, quiniela) {
  const claims = await getClaims(quinielaId);
  const assignments = await getAssignments(quinielaId);
  const assignedCodes = new Set(assignments.map((a) => a.team_code));
  const claimsByTeam = /* @__PURE__ */ new Map();
  for (const claim of claims) {
    if (!claimsByTeam.has(claim.team_code)) claimsByTeam.set(claim.team_code, []);
    claimsByTeam.get(claim.team_code).push(claim.participant_id);
  }
  for (const [teamCode, participantIds] of claimsByTeam.entries()) {
    if (assignedCodes.has(teamCode)) continue;
    const team = TEAMS.find((t) => t.code === teamCode);
    if (!team) continue;
    const tierPrice = team.tier === "favorito" ? quiniela.favoritoPrice : team.tier === "creyente" ? quiniela.creyentePrice : quiniela.maletePrice;
    const share = 100 / participantIds.length;
    const eachPays = Math.ceil(tierPrice / participantIds.length);
    for (const pid of participantIds) {
      await insertTeamAssignment({ quinielaId, participantId: pid, teamCode, assignmentType: "claimed", sharePercentage: share, extraPaid: eachPays });
    }
  }
  await updateQuinielaStatus(quinielaId, "active");
}
async function assignTeamsFull(quinielaId) {
  const participants = await getParticipants(quinielaId);
  const N = participants.length;
  if (N === 0) throw new Error("No hay participantes en la quiniela");
  await clearAssignments(quinielaId);
  const sortedTeams = [...TEAMS].sort((a, b) => {
    const ra = TEAM_INFO[a.code]?.fifaRank ?? 999;
    const rb = TEAM_INFO[b.code]?.fifaRank ?? 999;
    return ra - rb;
  });
  let assigned = 0;
  const fullRounds = Math.floor(sortedTeams.length / N);
  for (let round = 0; round < fullRounds; round++) {
    const group = sortedTeams.slice(round * N, (round + 1) * N);
    const shuffledParticipants = shuffleArray(participants);
    for (let i = 0; i < group.length; i++) {
      await insertTeamAssignment({
        quinielaId,
        participantId: shuffledParticipants[i].id,
        teamCode: group[i].code,
        assignmentType: "full_random",
        sharePercentage: 100,
        extraPaid: 0
      });
      assigned++;
    }
  }
  const leftoverTeams = shuffleArray(sortedTeams.slice(fullRounds * N));
  const shuffledForLeftover = shuffleArray(participants);
  for (let i = 0; i < leftoverTeams.length; i++) {
    await insertTeamAssignment({
      quinielaId,
      participantId: shuffledForLeftover[i % N].id,
      teamCode: leftoverTeams[i].code,
      assignmentType: "full_random",
      sharePercentage: 100,
      extraPaid: 0
    });
    assigned++;
  }
  await updateQuinielaStatus(quinielaId, "active");
  return { assigned };
}
async function getLeftoverTeams(quinielaId) {
  const assignments = await getAssignments(quinielaId);
  const assignedCodes = new Set(assignments.map((a) => a.team_code));
  return TEAMS.filter((t) => !assignedCodes.has(t.code)).map((t) => t.code);
}
async function calculateTotalPool(basePrice, participantCount, quinielaId) {
  const base = basePrice * participantCount;
  const assignments = await getAssignments(quinielaId);
  const extra = assignments.filter((a) => a.assignment_type === "claimed").reduce((sum, a) => sum + (a.extra_paid ?? 0), 0);
  return base + extra;
}

export { TEAMS as T, WC2026_GROUPS as W, TEAM_INFO as a, TIER_CONFIG as b, assignTeams as c, assignTeamsFull as d, calculateTotalPool as e, getTeam as f, getLeftoverTeams as g, resolveClaims as r };
