import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: process.env["DB_HOST"] ?? "localhost",
  user: process.env["DB_USER"] ?? "root",
  password: process.env["DB_PASS"] ?? "",
  database: process.env["DB_NAME"] ?? "quiniela",
  waitForConnections: true,
  connectionLimit: 10
});
let schemaReady = false;
async function getDb() {
  if (!schemaReady) {
    await initSchema();
    schemaReady = true;
  }
  return pool;
}
async function initSchema() {
  const statements = [
    `CREATE TABLE IF NOT EXISTS admin_users (
      id            INT AUTO_INCREMENT PRIMARY KEY,
      username      VARCHAR(100) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS sessions (
      id         INT AUTO_INCREMENT PRIMARY KEY,
      token      VARCHAR(255) UNIQUE NOT NULL,
      admin_id   INT NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS quinielas (
      id              INT AUTO_INCREMENT PRIMARY KEY,
      slug            VARCHAR(50) UNIQUE NOT NULL,
      name            VARCHAR(255) NOT NULL,
      tournament      VARCHAR(100) NOT NULL DEFAULT 'world_cup_2026',
      base_price      INT NOT NULL DEFAULT 300,
      favorito_price  INT NOT NULL DEFAULT 150,
      creyente_price  INT NOT NULL DEFAULT 100,
      malete_price    INT NOT NULL DEFAULT 50,
      status          VARCHAR(20) NOT NULL DEFAULT 'setup',
      mode            VARCHAR(20) NOT NULL DEFAULT 'reclamo',
      created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS participants (
      id           INT AUTO_INCREMENT PRIMARY KEY,
      quiniela_id  INT NOT NULL,
      name         VARCHAR(255) NOT NULL,
      email        VARCHAR(255) NOT NULL,
      access_token VARCHAR(255) UNIQUE NOT NULL,
      created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (quiniela_id) REFERENCES quinielas(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS team_assignments (
      id               INT AUTO_INCREMENT PRIMARY KEY,
      quiniela_id      INT NOT NULL,
      participant_id   INT NOT NULL,
      team_code        VARCHAR(10) NOT NULL,
      assignment_type  VARCHAR(20) NOT NULL DEFAULT 'random',
      share_percentage DOUBLE NOT NULL DEFAULT 100.0,
      extra_paid       INT NOT NULL DEFAULT 0,
      UNIQUE KEY uq_assignment (quiniela_id, participant_id, team_code),
      FOREIGN KEY (quiniela_id)    REFERENCES quinielas(id)    ON DELETE CASCADE,
      FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS team_claims (
      id             INT AUTO_INCREMENT PRIMARY KEY,
      quiniela_id    INT NOT NULL,
      participant_id INT NOT NULL,
      team_code      VARCHAR(10) NOT NULL,
      created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_claim (quiniela_id, participant_id, team_code),
      FOREIGN KEY (quiniela_id)    REFERENCES quinielas(id)    ON DELETE CASCADE,
      FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS match_cache (
      id         INT AUTO_INCREMENT PRIMARY KEY,
      cache_key  VARCHAR(255) UNIQUE NOT NULL,
      data_json  MEDIUMTEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB`
  ];
  for (const sql of statements) await pool.execute(sql);
  try {
    await pool.execute("ALTER TABLE quinielas ADD COLUMN mode VARCHAR(20) NOT NULL DEFAULT 'reclamo'");
  } catch {
  }
}
async function getAdminByUsername(username) {
  const db = await getDb();
  const [rows] = await db.execute("SELECT * FROM admin_users WHERE username = ?", [username]);
  return rows[0];
}
async function countAdmins() {
  const db = await getDb();
  const [rows] = await db.execute("SELECT COUNT(*) as count FROM admin_users");
  return rows[0].count;
}
async function createAdmin(username, passwordHash) {
  const db = await getDb();
  const [result] = await db.execute(
    "INSERT INTO admin_users (username, password_hash) VALUES (?, ?)",
    [username, passwordHash]
  );
  return result.insertId;
}
async function createSession(token, adminId, expiresAt) {
  const db = await getDb();
  await db.execute("INSERT INTO sessions (token, admin_id, expires_at) VALUES (?, ?, ?)", [token, adminId, expiresAt]);
}
async function getSession(token) {
  const db = await getDb();
  const [rows] = await db.execute(`
    SELECT s.*, a.username FROM sessions s
    JOIN admin_users a ON a.id = s.admin_id
    WHERE s.token = ? AND s.expires_at > NOW()
  `, [token]);
  return rows[0];
}
async function deleteSession(token) {
  const db = await getDb();
  await db.execute("DELETE FROM sessions WHERE token = ?", [token]);
}
async function createQuiniela(data) {
  const db = await getDb();
  const [result] = await db.execute(
    `INSERT INTO quinielas (slug, name, tournament, base_price, favorito_price, creyente_price, malete_price, mode)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [data.slug, data.name, data.tournament, data.basePrice, data.favoritoPrice, data.creyentePrice, data.maletePrice, data.mode]
  );
  return result.insertId;
}
async function getAllQuinielas() {
  const db = await getDb();
  const [rows] = await db.execute(`
    SELECT q.*, COUNT(p.id) as participant_count
    FROM quinielas q LEFT JOIN participants p ON p.quiniela_id = q.id
    GROUP BY q.id ORDER BY q.created_at DESC
  `);
  return rows;
}
async function getQuinielById(id) {
  const db = await getDb();
  const [rows] = await db.execute("SELECT * FROM quinielas WHERE id = ?", [id]);
  return rows[0];
}
async function getQuinielBySlug(slug) {
  const db = await getDb();
  const [rows] = await db.execute("SELECT * FROM quinielas WHERE slug = ?", [slug]);
  return rows[0];
}
async function updateQuinielaStatus(id, status) {
  const db = await getDb();
  await db.execute("UPDATE quinielas SET status = ? WHERE id = ?", [status, id]);
}
async function deleteQuiniela(id) {
  const db = await getDb();
  await db.execute("DELETE FROM quinielas WHERE id = ?", [id]);
}
async function resetQuiniela(id) {
  const db = await getDb();
  await db.execute("DELETE FROM team_assignments WHERE quiniela_id = ?", [id]);
  await db.execute("DELETE FROM team_claims WHERE quiniela_id = ?", [id]);
  await db.execute("UPDATE quinielas SET status = 'setup' WHERE id = ?", [id]);
}
async function addParticipant(data) {
  const db = await getDb();
  const [result] = await db.execute(
    "INSERT INTO participants (quiniela_id, name, email, access_token) VALUES (?, ?, ?, ?)",
    [data.quinielaId, data.name, data.email, data.accessToken]
  );
  return result.insertId;
}
async function getParticipants(quinielaId) {
  const db = await getDb();
  const [rows] = await db.execute(
    "SELECT * FROM participants WHERE quiniela_id = ? ORDER BY created_at",
    [quinielaId]
  );
  return rows;
}
async function getParticipantByToken(token) {
  const db = await getDb();
  const [rows] = await db.execute("SELECT * FROM participants WHERE access_token = ?", [token]);
  return rows[0];
}
async function deleteParticipant(id) {
  const db = await getDb();
  await db.execute("DELETE FROM participants WHERE id = ?", [id]);
}
async function insertTeamAssignment(data) {
  const db = await getDb();
  await db.execute(`
    INSERT INTO team_assignments (quiniela_id, participant_id, team_code, assignment_type, share_percentage, extra_paid)
    VALUES (?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      assignment_type  = VALUES(assignment_type),
      share_percentage = VALUES(share_percentage),
      extra_paid       = VALUES(extra_paid)
  `, [data.quinielaId, data.participantId, data.teamCode, data.assignmentType, data.sharePercentage, data.extraPaid]);
}
async function getAssignments(quinielaId) {
  const db = await getDb();
  const [rows] = await db.execute(`
    SELECT ta.*, p.name as participant_name
    FROM team_assignments ta JOIN participants p ON p.id = ta.participant_id
    WHERE ta.quiniela_id = ? ORDER BY p.name, ta.team_code
  `, [quinielaId]);
  return rows;
}
async function clearAssignments(quinielaId) {
  const db = await getDb();
  await db.execute("DELETE FROM team_assignments WHERE quiniela_id = ?", [quinielaId]);
  await db.execute("DELETE FROM team_claims WHERE quiniela_id = ?", [quinielaId]);
}
async function addClaim(quinielaId, participantId, teamCode) {
  const db = await getDb();
  await db.execute(
    "INSERT IGNORE INTO team_claims (quiniela_id, participant_id, team_code) VALUES (?, ?, ?)",
    [quinielaId, participantId, teamCode]
  );
}
async function removeClaim(quinielaId, participantId, teamCode) {
  const db = await getDb();
  await db.execute(
    "DELETE FROM team_claims WHERE quiniela_id = ? AND participant_id = ? AND team_code = ?",
    [quinielaId, participantId, teamCode]
  );
}
async function getClaims(quinielaId) {
  const db = await getDb();
  const [rows] = await db.execute(`
    SELECT tc.*, p.name as participant_name
    FROM team_claims tc JOIN participants p ON p.id = tc.participant_id
    WHERE tc.quiniela_id = ?
  `, [quinielaId]);
  return rows;
}
async function getCachedData(cacheKey, maxAgeMinutes = 10) {
  const db = await getDb();
  const cutoff = new Date(Date.now() - maxAgeMinutes * 60 * 1e3).toISOString().slice(0, 19).replace("T", " ");
  const [rows] = await db.execute(
    "SELECT data_json FROM match_cache WHERE cache_key = ? AND updated_at > ?",
    [cacheKey, cutoff]
  );
  return rows[0]?.data_json ?? null;
}
async function setCachedData(cacheKey, dataJson) {
  const db = await getDb();
  await db.execute(
    "INSERT INTO match_cache (cache_key, data_json) VALUES (?, ?) ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = NOW()",
    [cacheKey, dataJson]
  );
}

export { addClaim as a, addParticipant as b, clearAssignments as c, countAdmins as d, createAdmin as e, createQuiniela as f, createSession as g, deleteParticipant as h, deleteQuiniela as i, deleteSession as j, getAdminByUsername as k, getAllQuinielas as l, getAssignments as m, getCachedData as n, getClaims as o, getParticipantByToken as p, getParticipants as q, getQuinielById as r, getQuinielBySlug as s, getSession as t, insertTeamAssignment as u, removeClaim as v, resetQuiniela as w, setCachedData as x, updateQuinielaStatus as y };
