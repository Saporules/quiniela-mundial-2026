import { a2 as createComponent, _ as addAttribute, af as renderHead, ak as renderTemplate, ai as renderSlot, a1 as createAstro } from './astro/server_S7tF6J1M.mjs';
import 'piccolore';
import 'clsx';
/* empty css                             */

const $$Astro = createAstro();
const $$Layout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title, description = "Quiniela del Mundial 2026 con tus amigos", isAdmin = false } = Astro2.props;
  return renderTemplate`<html lang="es" class="scroll-smooth"> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="description"${addAttribute(description, "content")}><title>${title} | Quiniela Mundial 2026</title><link rel="icon" type="image/svg+xml"${addAttribute(`${"/quiniela/"}favicon.svg`, "href")}><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Bebas+Neue&display=swap" rel="stylesheet"><link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/regular/style.css"><link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/fill/style.css"><link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/bold/style.css">${renderHead()}</head> <body> <nav class="glass sticky top-0 z-50 border-b border-wc-border"> <div class="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between"> <a${addAttribute("/quiniela/", "href")} class="flex items-center gap-2"> <i class="ph-fill ph-trophy text-wc-gold text-2xl"></i> <span class="font-display text-xl text-wc-gold tracking-wide">QUINIELA 2026</span> </a> <div class="flex items-center gap-3"> ${isAdmin && renderTemplate`<a${addAttribute(`${"/quiniela/"}admin/dashboard`, "href")} class="text-sm text-wc-muted hover:text-white transition-colors">
Panel Admin
</a>
          <form${addAttribute(`${"/quiniela/"}api/auth/logout`, "action")} method="post"> <button type="submit" class="text-xs px-3 py-1.5 rounded-lg border border-wc-border text-wc-muted hover:text-wc-red hover:border-wc-red transition-colors">
Salir
</button> </form>`} ${!isAdmin && renderTemplate`<a${addAttribute(`${"/quiniela/"}admin`, "href")} class="text-xs text-wc-muted hover:text-white transition-colors">
Admin
</a>`} </div> </div> </nav> <main> ${renderSlot($$result, $$slots["default"])} </main> <footer class="mt-16 py-6 border-t border-wc-border text-center text-xs text-wc-muted"> <p>Quiniela Mundial 2026 &middot; USA &middot; Canada &middot; Mexico</p> <p class="mt-1 opacity-50"> <i class="ph ph-clock"></i> Horarios en tiempo de Mexico (UTC-6)
</p> </footer> </body></html>`;
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/layouts/Layout.astro", void 0);

export { $$Layout as $ };
