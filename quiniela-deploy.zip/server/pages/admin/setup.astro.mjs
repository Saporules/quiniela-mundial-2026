/* empty css                                        */
import { a2 as createComponent, ad as renderComponent, ak as renderTemplate, a1 as createAstro, aa as maybeRenderHead, _ as addAttribute } from '../../chunks/astro/server_S7tF6J1M.mjs';
import 'piccolore';
import { $ as $$Layout } from '../../chunks/Layout_CLHYjC69.mjs';
import { d as countAdmins } from '../../chunks/db_Y1fRCVEg.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro = createAstro();
const $$Setup = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Setup;
  if (await countAdmins() > 0) return Astro2.redirect(`${"/quiniela/"}admin`);
  let error = "";
  if (Astro2.url.searchParams.get("error") === "1") {
    error = "Error al crear la cuenta. Verifica que las contrasenas coincidan.";
  }
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Configuracion inicial" }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="min-h-[80vh] flex items-center justify-center px-4"> <div class="w-full max-w-sm"> <div class="text-center mb-8"> <i class="ph-fill ph-gear text-wc-gold" style="font-size:3.5rem"></i> <h1 class="font-display text-3xl text-wc-gold tracking-wide mt-2">PRIMER USO</h1> <p class="text-wc-muted text-sm mt-1">Crea tu cuenta de administrador</p> </div> <div class="card p-6"> ${error && renderTemplate`<div class="mb-4 p-3 rounded-lg bg-wc-red/10 border border-wc-red/30 text-wc-red text-sm flex items-center gap-2"> <i class="ph ph-warning-circle flex-shrink-0"></i> ${error} </div>`} <form${addAttribute(`${"/quiniela/"}api/admin/setup`, "action")} method="post" class="space-y-4"> <div> <label class="block text-sm font-medium mb-1.5" for="username">Usuario</label> <div class="relative"> <i class="ph ph-user absolute left-3 top-1/2 -translate-y-1/2 text-wc-muted"></i> <input id="username" name="username" type="text" class="input-field input-with-icon" placeholder="ej: guero" autocomplete="username" required autofocus minlength="3"> </div> </div> <div> <label class="block text-sm font-medium mb-1.5" for="password">Contrasena</label> <div class="relative"> <i class="ph ph-lock absolute left-3 top-1/2 -translate-y-1/2 text-wc-muted"></i> <input id="password" name="password" type="password" class="input-field input-with-icon" placeholder="Minimo 8 caracteres" autocomplete="new-password" required minlength="8"> </div> </div> <div> <label class="block text-sm font-medium mb-1.5" for="confirm">Confirmar contrasena</label> <div class="relative"> <i class="ph ph-lock-key absolute left-3 top-1/2 -translate-y-1/2 text-wc-muted"></i> <input id="confirm" name="confirm" type="password" class="input-field input-with-icon" placeholder="Repite tu contrasena" autocomplete="new-password" required minlength="8"> </div> </div> <button type="submit" class="btn-gold w-full py-2.5 rounded-lg flex items-center justify-center gap-2">
Crear cuenta y continuar <i class="ph ph-arrow-right"></i> </button> </form> </div> <p class="text-center text-xs text-wc-muted mt-4">
Esta pantalla solo aparece una vez. Guarda bien tus credenciales.
</p> </div> </div> ` })}`;
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/pages/admin/setup.astro", void 0);
const $$file = "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/pages/admin/setup.astro";
const $$url = "/quiniela/admin/setup";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Setup,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
