/* empty css                                        */
import { a2 as createComponent, aa as maybeRenderHead, ak as renderTemplate, a1 as createAstro, _ as addAttribute, ad as renderComponent } from '../../chunks/astro/server_S7tF6J1M.mjs';
import 'piccolore';
import { $ as $$Layout } from '../../chunks/Layout_CLHYjC69.mjs';
import 'clsx';
import { f as getTeam, W as WC2026_GROUPS, T as TEAMS, b as TIER_CONFIG, a as TEAM_INFO, g as getLeftoverTeams } from '../../chunks/assignment_C28mivLj.mjs';
import { n as getCachedData, x as setCachedData, s as getQuinielBySlug, p as getParticipantByToken, a as addClaim, v as removeClaim, q as getParticipants, m as getAssignments, o as getClaims } from '../../chunks/db_Y1fRCVEg.mjs';
export { renderers } from '../../renderers.mjs';

const $$Astro$3 = createAstro();
const $$GroupStage = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$GroupStage;
  const { assignments } = Astro2.props;
  function getOwners(teamCode) {
    return assignments.filter((a) => a.team_code === teamCode);
  }
  const groups = Object.entries(WC2026_GROUPS);
  return renderTemplate`${maybeRenderHead()}<section> <h2 class="font-display text-3xl text-wc-gold mb-6 tracking-wide">FASE DE GRUPOS</h2> <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4"> ${groups.map(([groupName, teamCodes]) => renderTemplate`<div class="card p-4"> <div class="flex items-center gap-2 mb-3"> <div class="w-8 h-8 rounded-lg bg-wc-gold/20 border border-wc-gold/40 flex items-center justify-center"> <span class="font-display text-wc-gold text-lg">${groupName}</span> </div> <span class="font-semibold text-sm text-wc-muted">Grupo ${groupName}</span> </div> <div class="overflow-x-auto -mx-1"> <table class="w-full text-xs"> <thead> <tr class="text-wc-muted border-b border-wc-border"> <th class="text-left py-1.5 px-1 font-medium">Equipo</th> <th class="px-1 font-medium">J</th> <th class="px-1 font-medium">G</th> <th class="px-1 font-medium">E</th> <th class="px-1 font-medium">P</th> <th class="px-1 font-medium">GD</th> <th class="px-1 font-medium text-wc-gold">Pts</th> </tr> </thead> <tbody class="divide-y divide-wc-border/40"> ${teamCodes.map((code, pos) => {
    const team = getTeam(code);
    const owners = getOwners(code);
    if (!team) return null;
    return renderTemplate`<tr class="hover:bg-wc-blue/10 transition-colors"> <td class="py-2 px-1"> <div class="flex items-center gap-1.5"> ${pos < 2 && renderTemplate`<div class="w-0.5 h-4 rounded-full bg-wc-gold/60 -ml-1 mr-0.5"></div>`} <span class="text-base">${team.flag}</span> <div> <span class="font-medium">${team.name}</span> ${owners.length > 0 && renderTemplate`<div class="flex flex-wrap gap-1 mt-0.5"> ${owners.map((o) => renderTemplate`<span class="text-[10px] px-1.5 py-0 rounded-full bg-blue-900/50 text-blue-300"> ${o.share_percentage < 100 ? `${o.share_percentage.toFixed(0)}% ` : ""}${o.participant_name} </span>`)} </div>`} </div> </div> </td> <td class="text-center px-1 text-wc-muted">0</td> <td class="text-center px-1 text-wc-muted">0</td> <td class="text-center px-1 text-wc-muted">0</td> <td class="text-center px-1 text-wc-muted">0</td> <td class="text-center px-1 text-wc-muted">0</td> <td class="text-center px-1 font-bold text-white">0</td> </tr>`;
  })} </tbody> </table> </div> <p class="text-[10px] text-wc-muted mt-2 opacity-60 flex items-center gap-1"> <i class="ph ph-arrow-up"></i> Top 2 avanzan &middot; Mejor 3ro califica
</p> </div>`)} </div> </section>`;
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/components/GroupStage.astro", void 0);

var __freeze$2 = Object.freeze;
var __defProp$2 = Object.defineProperty;
var __template$2 = (cooked, raw) => __freeze$2(__defProp$2(cooked, "raw", { value: __freeze$2(cooked.slice()) }));
var _a$2;
const $$Astro$2 = createAstro();
const $$Bracket = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Bracket;
  const { assignments } = Astro2.props;
  const rounds = [
    {
      name: "Ronda 32",
      short: "R32",
      matches: Array.from({ length: 16 }, (_, i) => ({
        id: `r32-${i}`,
        home: null,
        away: null,
        homeScore: null,
        awayScore: null,
        status: "pre"
      }))
    },
    {
      name: "Octavos",
      short: "R16",
      matches: Array.from({ length: 8 }, (_, i) => ({
        id: `r16-${i}`,
        home: null,
        away: null,
        homeScore: null,
        awayScore: null,
        status: "pre"
      }))
    },
    {
      name: "Cuartos",
      short: "QF",
      matches: Array.from({ length: 4 }, (_, i) => ({
        id: `qf-${i}`,
        home: null,
        away: null,
        homeScore: null,
        awayScore: null,
        status: "pre"
      }))
    },
    {
      name: "Semis",
      short: "SF",
      matches: Array.from({ length: 2 }, (_, i) => ({
        id: `sf-${i}`,
        home: null,
        away: null,
        homeScore: null,
        awayScore: null,
        status: "pre"
      }))
    },
    {
      name: "Final",
      short: "F",
      matches: [{ id: "final", home: null, away: null, homeScore: null, awayScore: null, status: "pre" }]
    }
  ];
  return renderTemplate(_a$2 || (_a$2 = __template$2(["", '<section> <h2 class="font-display text-3xl text-wc-gold mb-2 tracking-wide">LLAVES</h2> <p class="text-sm text-wc-muted mb-4">La fase eliminatoria comienza cuando terminan los grupos</p> <!-- Toggle button --> <div class="flex items-center gap-3 mb-6"> <button id="bracket-toggle" onclick="toggleBracketView()" class="flex items-center gap-2 text-xs px-3 py-1.5 rounded-lg border border-wc-border text-wc-muted hover:text-white hover:border-wc-gold/40 transition-colors"> <i class="ph ph-list" id="bracket-toggle-icon"></i> <span id="bracket-toggle-label">Ver en lista</span> </button> </div> <!-- BRACKET VISUAL (default) --> <div id="bracket-visual" class="overflow-x-auto pb-4 cursor-grab select-none" style="scroll-behavior:smooth"> <div style="width:max-content;margin:0 auto;padding:1.5rem 3rem"> <div class="relative flex items-center gap-4 py-8"> <!-- LEFT: R32(0-7) → R16(0-3) → QF(0-1) → SF(0) --> <div class="flex gap-4 items-center"> <!-- R32 left --> <div class="flex flex-col gap-2" style="width:160px"> <p class="font-display text-wc-muted text-xs text-center mb-1">RONDA 32</p> ', ' </div> <!-- R16 left --> <div class="flex flex-col gap-8 justify-around" style="width:160px"> <p class="font-display text-wc-muted text-xs text-center mb-1">OCTAVOS</p> ', ' </div> <!-- QF left --> <div class="flex flex-col gap-24 justify-around" style="width:140px"> <p class="font-display text-wc-muted text-xs text-center mb-1">CUARTOS</p> ', ' </div> <!-- SF left --> <div class="flex flex-col justify-center" style="width:140px"> <p class="font-display text-wc-muted text-xs text-center mb-1">SEMIFINAL</p> <div class="bracket-match card p-2 text-xs mt-8"> <div class="flex justify-between items-center py-0.5"> <span class="text-wc-muted truncate">', '</span> <span class="font-bold ml-2 text-wc-gold">-</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="text-wc-muted truncate">', '</span> <span class="font-bold ml-2 text-wc-gold">-</span> </div> </div> </div> </div> <!-- CENTER: Copa + Final --> <div class="flex flex-col items-center gap-4 px-4" style="min-width:200px"> <img', ' alt="Copa del Mundo" class="drop-shadow-[0_0_40px_rgba(249,168,37,0.5)]" style="width:120px;height:auto"> <div class="text-center"> <p class="font-display text-wc-gold text-xl tracking-widest mb-2">GRAN FINAL</p> <div class="card p-3 border-wc-gold/40 min-w-[180px]"> <div class="flex justify-between items-center py-1"> <span class="text-white font-semibold">', '</span> <span class="font-display text-wc-gold text-xl ml-3">-</span> </div> <div class="border-t border-wc-border my-1"></div> <div class="flex justify-between items-center py-1"> <span class="text-white font-semibold">', '</span> <span class="font-display text-wc-gold text-xl ml-3">-</span> </div> </div> </div> </div> <!-- RIGHT: SF(1) → QF(2-3) → R16(4-7) → R32(8-15) — score left, name right --> <div class="flex gap-4 items-center"> <!-- SF right --> <div class="flex flex-col justify-center" style="width:140px"> <p class="font-display text-wc-muted text-xs text-center mb-1">SEMIFINAL</p> <div class="bracket-match card p-2 text-xs mt-8"> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">-</span> <span class="text-wc-muted truncate text-right">', '</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">-</span> <span class="text-wc-muted truncate text-right">', '</span> </div> </div> </div> <!-- QF right --> <div class="flex flex-col gap-24 justify-around" style="width:140px"> <p class="font-display text-wc-muted text-xs text-center mb-1">CUARTOS</p> ', ' </div> <!-- R16 right --> <div class="flex flex-col gap-8 justify-around" style="width:160px"> <p class="font-display text-wc-muted text-xs text-center mb-1">OCTAVOS</p> ', ' </div> <!-- R32 right --> <div class="flex flex-col gap-2" style="width:160px"> <p class="font-display text-wc-muted text-xs text-center mb-1">RONDA 32</p> ', ' </div> </div> </div> </div><!-- /max-content wrapper --> </div> <!-- LIST VIEW (hidden by default) --> <div id="bracket-list" class="hidden"> <div class="flex overflow-x-auto gap-2 pb-2 mb-4"> ', " </div> ", " </div> </section> <script>\nvar _bracketShowingVisual = true\n\nfunction toggleBracketView() {\n  _bracketShowingVisual = !_bracketShowingVisual\n  document.getElementById('bracket-visual').classList.toggle('hidden', !_bracketShowingVisual)\n  document.getElementById('bracket-list').classList.toggle('hidden', _bracketShowingVisual)\n  document.getElementById('bracket-toggle-icon').className = _bracketShowingVisual ? 'ph ph-list' : 'ph ph-graph'\n  document.getElementById('bracket-toggle-label').textContent = _bracketShowingVisual ? 'Ver en lista' : 'Ver llaves'\n}\n\nfunction showRound(idx) {\n  document.querySelectorAll('.bracket-round-mobile').forEach((el, i) => {\n    el.style.display = i === idx ? 'block' : 'none'\n  })\n  document.querySelectorAll('.bracket-tab').forEach((btn, i) => {\n    btn.classList.toggle('bg-wc-gold', i === idx)\n    btn.classList.toggle('text-wc-dark', i === idx)\n    btn.classList.toggle('bg-wc-card', i !== idx)\n    btn.classList.toggle('text-wc-muted', i !== idx)\n  })\n}\n\n// Drag-to-scroll for desktop\n;(function () {\n  const el = document.getElementById('bracket-visual')\n  if (!el) return\n  let isDown = false, startX = 0, scrollLeft = 0\n\n  el.addEventListener('mousedown', (e) => {\n    isDown = true\n    el.style.cursor = 'grabbing'\n    startX = e.pageX - el.offsetLeft\n    scrollLeft = el.scrollLeft\n    e.preventDefault()\n  })\n  el.addEventListener('mouseleave', () => { isDown = false; el.style.cursor = 'grab' })\n  el.addEventListener('mouseup',    () => { isDown = false; el.style.cursor = 'grab' })\n  el.addEventListener('mousemove',  (e) => {\n    if (!isDown) return\n    e.preventDefault()\n    const x    = e.pageX - el.offsetLeft\n    const walk = (x - startX) * 1.5\n    el.scrollLeft = scrollLeft - walk\n  })\n\n  // Center the bracket on load\n  el.scrollLeft = (el.scrollWidth - el.clientWidth) / 2\n})()\n</script>"])), maybeRenderHead(), rounds[0].matches.slice(0, 8).map((m) => renderTemplate`<div class="bracket-match card p-2 text-xs"> <div class="flex justify-between items-center py-0.5 hover:text-white transition-colors"> <span class="text-wc-muted truncate">${m.home ?? "TBD"}</span> <span class="font-bold ml-2 text-wc-gold">${m.homeScore ?? "-"}</span> </div> <div class="flex justify-between items-center py-0.5 hover:text-white transition-colors"> <span class="text-wc-muted truncate">${m.away ?? "TBD"}</span> <span class="font-bold ml-2 text-wc-gold">${m.awayScore ?? "-"}</span> </div> </div>`), rounds[1].matches.slice(0, 4).map((m) => renderTemplate`<div class="bracket-match card p-2 text-xs"> <div class="flex justify-between items-center py-0.5"> <span class="text-wc-muted truncate">${m.home ?? "TBD"}</span> <span class="font-bold ml-2 text-wc-gold">${m.homeScore ?? "-"}</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="text-wc-muted truncate">${m.away ?? "TBD"}</span> <span class="font-bold ml-2 text-wc-gold">${m.awayScore ?? "-"}</span> </div> </div>`), rounds[2].matches.slice(0, 2).map((m) => renderTemplate`<div class="bracket-match card p-2 text-xs"> <div class="flex justify-between items-center py-0.5"> <span class="text-wc-muted truncate">${m.home ?? "TBD"}</span> <span class="font-bold ml-2 text-wc-gold">${m.homeScore ?? "-"}</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="text-wc-muted truncate">${m.away ?? "TBD"}</span> <span class="font-bold ml-2 text-wc-gold">${m.awayScore ?? "-"}</span> </div> </div>`), rounds[3].matches[0].home ?? "TBD", rounds[3].matches[0].away ?? "TBD", addAttribute(`${"/quiniela/"}copa-del-mundo.png`, "src"), rounds[4].matches[0].home ?? "TBD", rounds[4].matches[0].away ?? "TBD", rounds[3].matches[1]?.home ?? "TBD", rounds[3].matches[1]?.away ?? "TBD", rounds[2].matches.slice(2, 4).map((m) => renderTemplate`<div class="bracket-match card p-2 text-xs"> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">${m.homeScore ?? "-"}</span> <span class="text-wc-muted truncate text-right">${m.home ?? "TBD"}</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">${m.awayScore ?? "-"}</span> <span class="text-wc-muted truncate text-right">${m.away ?? "TBD"}</span> </div> </div>`), rounds[1].matches.slice(4, 8).map((m) => renderTemplate`<div class="bracket-match card p-2 text-xs"> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">${m.homeScore ?? "-"}</span> <span class="text-wc-muted truncate text-right">${m.home ?? "TBD"}</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">${m.awayScore ?? "-"}</span> <span class="text-wc-muted truncate text-right">${m.away ?? "TBD"}</span> </div> </div>`), rounds[0].matches.slice(8, 16).map((m) => renderTemplate`<div class="bracket-match card p-2 text-xs"> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">${m.homeScore ?? "-"}</span> <span class="text-wc-muted truncate text-right">${m.home ?? "TBD"}</span> </div> <div class="flex justify-between items-center py-0.5"> <span class="font-bold mr-2 text-wc-gold">${m.awayScore ?? "-"}</span> <span class="text-wc-muted truncate text-right">${m.away ?? "TBD"}</span> </div> </div>`), rounds.map((r, i) => renderTemplate`<button${addAttribute(["bracket-tab flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-colors", i === 4 ? "bg-wc-gold text-wc-dark" : "bg-wc-card border border-wc-border text-wc-muted hover:text-white"], "class:list")}${addAttribute(i, "data-round")}${addAttribute(`showRound(${i})`, "onclick")}> ${r.short} </button>`), rounds.map((round, roundIdx) => renderTemplate`<div class="bracket-round-mobile"${addAttribute(`round-${roundIdx}`, "id")}${addAttribute(roundIdx !== 4 ? "display:none" : "", "style")}> <h3 class="font-semibold text-wc-gold mb-3">${round.name}</h3> <div class="space-y-2"> ${round.matches.map((match) => renderTemplate`<div class="card p-3 flex items-center gap-3"> <div class="flex-1 text-sm font-medium text-wc-muted"> ${match.home ?? "Por definir"} </div> <div class="px-3 py-1 bg-wc-dark rounded font-display text-wc-gold text-lg"> ${match.homeScore !== null ? match.homeScore : "-"} : ${match.awayScore !== null ? match.awayScore : "-"} </div> <div class="flex-1 text-sm font-medium text-wc-muted text-right"> ${match.away ?? "Por definir"} </div> </div>`)} </div> </div>`));
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/components/Bracket.astro", void 0);

const ESPN_BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer";
const MEXICO_TZ = "America/Mexico_City";
const LEAGUE_SLUGS = {
  world_cup_2026: "fifa.world",
  champions_league: "uefa.champions",
  liga_mx: "mex.1",
  laliga: "esp.1",
  premier_league: "eng.1"
};
async function fetchWithCache(url, cacheKey, maxAgeMinutes = 5) {
  const cached = await getCachedData(cacheKey, maxAgeMinutes);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
    }
  }
  try {
    const res = await fetch(url, {
      headers: { "Accept": "application/json", "User-Agent": "QuinielaMundial/1.0" },
      signal: AbortSignal.timeout(8e3)
    });
    if (!res.ok) return null;
    const data = await res.json();
    await setCachedData(cacheKey, JSON.stringify(data));
    return data;
  } catch {
    return null;
  }
}
function toDateParam(d) {
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}
const TOURNAMENT_START = {
  world_cup_2026: "2026-06-11"
};
async function getMatchSchedule(tournament = "world_cup_2026") {
  const slug = LEAGUE_SLUGS[tournament] ?? LEAGUE_SLUGS["world_cup_2026"];
  const now = /* @__PURE__ */ new Date();
  const startStr = TOURNAMENT_START[tournament];
  if (startStr) {
    const startDate = /* @__PURE__ */ new Date(startStr + "T00:00:00");
    if (now < startDate) {
      const openEnd = new Date(startDate);
      openEnd.setDate(openEnd.getDate() + 6);
      const weekData2 = await fetchWithCache(
        `${ESPN_BASE}/${slug}/scoreboard?dates=${toDateParam(startDate)}-${toDateParam(openEnd)}&limit=50`,
        `scoreboard:${slug}:opening:${toDateParam(startDate)}`,
        120
      );
      return { today: [], week: weekData2?.events ?? [], previewMode: true };
    }
  }
  const todayData = await fetchWithCache(
    `${ESPN_BASE}/${slug}/scoreboard?dates=${toDateParam(now)}`,
    `scoreboard:${slug}:${toDateParam(now)}`,
    3
  );
  const today = todayData?.events ?? [];
  const from = new Date(now);
  from.setDate(from.getDate() + 1);
  const to = new Date(now);
  to.setDate(to.getDate() + 7);
  const weekData = await fetchWithCache(
    `${ESPN_BASE}/${slug}/scoreboard?dates=${toDateParam(from)}-${toDateParam(to)}&limit=50`,
    `scoreboard:${slug}:week:${toDateParam(now)}`,
    60
  );
  const week = weekData?.events ?? [];
  return { today, week, previewMode: false };
}
function formatMatchTime(dateStr) {
  try {
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat("es-MX", {
      timeZone: MEXICO_TZ,
      weekday: "short",
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    }).format(date);
  } catch {
    return dateStr;
  }
}
function getMatchStatus(event) {
  const state = event.status.type.state;
  if (state === "pre") return "pre";
  if (state === "post") return "post";
  return "in";
}

const $$Astro$1 = createAstro();
const $$MatchCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$MatchCard;
  const { event } = Astro2.props;
  const status = getMatchStatus(event);
  const comp = event.competitions[0];
  const home = comp.competitors.find((c) => c.homeAway === "home");
  const away = comp.competitors.find((c) => c.homeAway === "away");
  const group = comp.groups?.name;
  return renderTemplate`${maybeRenderHead()}<div${addAttribute([
    "card p-3 sm:p-4 hover:border-wc-blue/50 transition-all",
    status === "in" && "border-wc-red/40 bg-wc-red/5"
  ], "class:list")}> ${group && renderTemplate`<p class="text-[10px] text-wc-muted mb-2 uppercase tracking-wider">${group}</p>`} <div class="flex items-center gap-2 sm:gap-4"> <div class="flex-1 flex flex-col items-center gap-1 text-center"> <img${addAttribute(home?.team.logo, "src")}${addAttribute(home?.team.displayName, "alt")} class="w-8 h-8 sm:w-10 sm:h-10 object-contain" onerror="this.style.display='none'"> <span class="text-xs font-medium">${home?.team.abbreviation ?? "?"}</span> </div> <div class="flex flex-col items-center gap-0.5 min-w-[80px]"> ${status === "pre" ? renderTemplate`<span class="font-display text-wc-gold text-lg tracking-wider text-center"> ${formatMatchTime(event.date)} </span>` : renderTemplate`<div class="flex items-center gap-2"> <span${addAttribute(["font-display text-2xl", home?.winner ? "text-white" : "text-wc-muted"], "class:list")}> ${home?.score ?? "0"} </span> <span class="text-wc-muted font-display text-xl">:</span> <span${addAttribute(["font-display text-2xl", away?.winner ? "text-white" : "text-wc-muted"], "class:list")}> ${away?.score ?? "0"} </span> </div>`} ${status === "in" && renderTemplate`<span class="text-[10px] text-wc-red font-medium flex items-center gap-1"> <i class="ph-fill ph-record animate-pulse"></i> ${event.status.displayClock || "En vivo"} </span>`} ${status === "post" && renderTemplate`<span class="text-[10px] text-wc-muted flex items-center gap-1"> <i class="ph ph-flag-checkered"></i> Final
</span>`} </div> <div class="flex-1 flex flex-col items-center gap-1 text-center"> <img${addAttribute(away?.team.logo, "src")}${addAttribute(away?.team.displayName, "alt")} class="w-8 h-8 sm:w-10 sm:h-10 object-contain" onerror="this.style.display='none'"> <span class="text-xs font-medium">${away?.team.abbreviation ?? "?"}</span> </div> </div> ${comp.venue && renderTemplate`<p class="text-[10px] text-wc-muted text-center mt-2 flex items-center justify-center gap-1"> <i class="ph ph-map-pin"></i> ${comp.venue.fullName}${comp.venue.address?.city ? `, ${comp.venue.address.city}` : ""} </p>`} </div>`;
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/components/MatchCard.astro", void 0);

var __freeze$1 = Object.freeze;
var __defProp$1 = Object.defineProperty;
var __template$1 = (cooked, raw) => __freeze$1(__defProp$1(cooked, "raw", { value: __freeze$1(cooked.slice()) }));
var _a$1;
const $$TeamsTab = createComponent(($$result, $$props, $$slots) => {
  const tiers = ["favorito", "creyente", "maleta"];
  const tierDescriptions = {
    favorito: "Los candidatos serios. Tienen el plantel, el historial y la presi\xF3n para ganar el torneo.",
    creyente: "Capaces de llegar lejos si los astros se alinean. Peligrosos en el momento correcto.",
    maleta: "El f\xFAtbol es redondo. Clasificaron con m\xE9rito y cualquier victoria es un regalo para tu quiniela."
  };
  const tierColors = {
    favorito: "text-wc-gold",
    creyente: "text-blue-400",
    maleta: "text-wc-muted"
  };
  return renderTemplate(_a$1 || (_a$1 = __template$1(["", '<section> <h2 class="font-display text-3xl text-wc-gold mb-6 tracking-wide">EQUIPOS</h2> ', ` </section> <!-- Shared tooltip --> <div id="teams-tooltip" class="hidden fixed z-50 w-[min(20rem,calc(100vw-2rem))] card p-4 border border-wc-blue/40 shadow-2xl" style="left:50%;top:50%;transform:translate(-50%,-50%)"> <div class="flex items-center gap-2 mb-3"> <span id="tt-flag" class="text-3xl leading-none"></span> <h4 id="tt-name" class="font-semibold text-white text-base"></h4> </div> <div class="flex gap-6 mb-3"> <div> <p class="text-[10px] text-wc-muted uppercase tracking-wide mb-0.5">Ranking FIFA</p> <p id="tt-rank" class="text-white font-bold text-xl leading-none"></p> </div> <div> <p class="text-[10px] text-wc-muted uppercase tracking-wide mb-0.5">Prob. campe\xF3n</p> <p id="tt-prob" class="text-wc-gold font-bold text-xl leading-none"></p> </div> </div> <p id="tt-summary" class="text-xs text-wc-muted leading-relaxed"></p> <button id="tt-close" class="mt-3 text-wc-gold text-xs underline underline-offset-2" type="button">Cerrar</button> </div> <script>
(function () {
  const tooltip = document.getElementById('teams-tooltip')
  if (!tooltip) return
  const ttFlag    = document.getElementById('tt-flag')
  const ttName    = document.getElementById('tt-name')
  const ttRank    = document.getElementById('tt-rank')
  const ttProb    = document.getElementById('tt-prob')
  const ttSummary = document.getElementById('tt-summary')
  const ttClose   = document.getElementById('tt-close')

  let locked = null

  function show(btn) {
    ttFlag.textContent    = btn.dataset.flag
    ttName.textContent    = btn.dataset.name
    ttRank.textContent    = '#' + btn.dataset.rank
    ttProb.textContent    = btn.dataset.prob
    ttSummary.textContent = btn.dataset.summary
    tooltip.classList.remove('hidden')
  }

  function hide() {
    locked = null
    tooltip.classList.add('hidden')
  }

  document.querySelectorAll('.team-info-btn').forEach(function (btn) {
    btn.addEventListener('mouseenter', function () {
      if (!locked) show(btn)
    })
    btn.addEventListener('mouseleave', function () {
      if (!locked) tooltip.classList.add('hidden')
    })
    btn.addEventListener('click', function (e) {
      e.stopPropagation()
      if (locked === btn) {
        hide()
      } else {
        locked = btn
        show(btn)
      }
    })
  })

  tooltip.addEventListener('click', function (e) { e.stopPropagation() })
  if (ttClose) ttClose.addEventListener('click', hide)
  document.addEventListener('click', hide)
})()
<\/script>`])), maybeRenderHead(), tiers.map((tier) => {
    const cfg = TIER_CONFIG[tier];
    const teams = TEAMS.filter((t) => t.tier === tier);
    const color = tierColors[tier];
    return renderTemplate`<div class="mb-8"> <div class="flex items-center gap-2 mb-1"> <i${addAttribute(["ph", cfg.icon, color, "text-base"], "class:list")}></i> <h3${addAttribute(["font-display text-xl tracking-wide", color], "class:list")}>${cfg.label.toUpperCase()}</h3> <span${addAttribute(["text-xs ml-1", color, "opacity-60"], "class:list")}>(${teams.length})</span> </div> <p class="text-xs text-wc-muted mb-3">${tierDescriptions[tier]}</p> <div class="flex flex-wrap gap-2"> ${teams.map((team) => {
      const info = TEAM_INFO[team.code];
      return renderTemplate`<button class="team-badge text-sm team-info-btn"${addAttribute(team.code, "data-code")}${addAttribute(team.name, "data-name")}${addAttribute(team.flag, "data-flag")}${addAttribute(info?.fifaRank ?? "?", "data-rank")}${addAttribute(info?.winProb ?? "?", "data-prob")}${addAttribute(info?.summary ?? "", "data-summary")} type="button"> ${team.flag} ${team.name} </button>`;
    })} </div> </div>`;
  }));
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/components/TeamsTab.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro();
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$slug;
  const { slug } = Astro2.params;
  const q = await getQuinielBySlug(slug);
  if (!q) return Astro2.redirect(`${"/quiniela/"}?error=notfound`);
  const token = Astro2.url.searchParams.get("token");
  const participant = token ? await getParticipantByToken(token) : null;
  const isParticipant = !!participant && participant.quiniela_id === q.id;
  if (Astro2.request.method === "POST" && isParticipant && q.status === "draft") {
    const form = await Astro2.request.formData();
    const action = form.get("action");
    const teamCode = form.get("team_code");
    if (action === "claim" && teamCode) await addClaim(q.id, participant.id, teamCode);
    if (action === "unclaim" && teamCode) await removeClaim(q.id, participant.id, teamCode);
    return Astro2.redirect(Astro2.url.pathname + (token ? `?token=${token}&tab=reclamos` : ""));
  }
  const tab = Astro2.url.searchParams.get("tab") ?? "grupos";
  const participants = await getParticipants(q.id);
  const assignments = await getAssignments(q.id);
  const claims = await getClaims(q.id);
  const leftover = q.status !== "setup" ? await getLeftoverTeams(q.id) : [];
  const { today: matchesToday, week: matchesWeek, previewMode } = await getMatchSchedule(q.tournament);
  const myTeams = isParticipant ? assignments.filter((a) => a.participant_id === participant.id).map((a) => ({ ...a, team: getTeam(a.team_code) })) : [];
  const myClaims = isParticipant ? claims.filter((c) => c.participant_id === participant.id).map((c) => c.team_code) : [];
  function assignmentsList() {
    return assignments.map((a) => ({
      team_code: a.team_code,
      participant_name: a.participant_name,
      share_percentage: a.share_percentage
    }));
  }
  return renderTemplate(_a || (_a = __template(["", " <script>\n(function () {\n  const btn     = document.getElementById('claim-info-btn')\n  const tooltip = document.getElementById('claim-info-tooltip')\n  const close   = document.getElementById('claim-info-close')\n  if (!btn || !tooltip) return\n\n  function toggle(e) {\n    e.stopPropagation()\n    tooltip.classList.toggle('hidden')\n  }\n  function hide() { tooltip.classList.add('hidden') }\n\n  btn.addEventListener('click', toggle)\n  if (close) close.addEventListener('click', hide)\n  document.addEventListener('click', function (e) {\n    if (!tooltip.contains(e.target) && e.target !== btn) hide()\n  })\n})()\n</script>"])), renderComponent($$result, "Layout", $$Layout, { "title": q.name }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="max-w-5xl mx-auto px-4 py-6"> <!-- Header --> <div class="mb-6"> <h1 class="font-display text-3xl sm:text-4xl text-wc-gold tracking-wide">${q.name}</h1> <div class="flex flex-wrap gap-3 mt-2 text-sm text-wc-muted"> <span class="flex items-center gap-1"><i class="ph ph-key"></i> ${q.slug}</span> <span class="flex items-center gap-1"><i class="ph ph-users"></i> ${participants.length} contendientes</span> <span class="flex items-center gap-1"> <i class="ph ph-currency-circle-dollar"></i> Bolsa:
<span class="text-wc-gold font-semibold">$${q.base_price * participants.length}+ MXN</span> </span> </div> </div> <!-- Participant greeting --> ${isParticipant && renderTemplate`<div class="card p-4 mb-6 border-wc-gold/20 bg-wc-gold/5"> <p class="text-sm">
¡Hola, <strong class="text-wc-gold">${participant.name}</strong>!
          Tienes <strong>${myTeams.length}</strong> equipos asignados.
${q.status === "draft" && leftover.length > 0 && renderTemplate`<span> Puedes reclamar equipos adicionales.</span>`} </p> ${myTeams.length > 0 && renderTemplate`<div class="flex flex-wrap gap-1.5 mt-3"> ${myTeams.map((a) => a.team && renderTemplate`<span class="team-badge text-xs"> ${a.team.flag} ${a.team.name} ${a.share_percentage < 100 && renderTemplate`<span class="text-wc-gold"> ${a.share_percentage.toFixed(0)}%</span>`} </span>`)} </div>`} </div>`} <!-- Tabs --> <div class="flex gap-1 border-b border-wc-border mb-6 overflow-x-auto"> ${[
    ["grupos", "ph-chart-bar", "Grupos"],
    ["llaves", "ph-fill ph-trophy", "Llaves"],
    ["partidos", "ph-fill ph-soccer-ball", "Partidos"],
    ["contendientes", "ph-users", "Contendientes"],
    ["equipos", "ph-globe", "Equipos"],
    ...isParticipant && q.status === "draft" && leftover.length > 0 && q.mode !== "full_random" ? [["reclamos", "ph-handshake", "Reclamar"]] : []
  ].map(([key, icon, label]) => renderTemplate`<a${addAttribute(`?${token ? `token=${token}&` : ""}tab=${key}`, "href")}${addAttribute([
    "px-4 py-2.5 text-sm font-medium whitespace-nowrap transition-colors border-b-2 -mb-px",
    tab === key ? "border-wc-gold text-wc-gold" : "border-transparent text-wc-muted hover:text-white"
  ], "class:list")}> <span class="flex items-center gap-1.5"> <i${addAttribute(["ph", icon, "text-sm"], "class:list")}></i> ${label} </span> </a>`)} </div> <!-- Tab: Grupos --> ${tab === "grupos" && renderTemplate`${renderComponent($$result2, "GroupStage", $$GroupStage, { "assignments": assignmentsList() })}`} <!-- Tab: Llaves --> ${tab === "llaves" && renderTemplate`${renderComponent($$result2, "Bracket", $$Bracket, { "assignments": assignmentsList() })}`} <!-- Tab: Partidos --> ${tab === "partidos" && renderTemplate`<section> <h2 class="font-display text-3xl text-wc-gold mb-2 tracking-wide">PARTIDOS</h2> <p class="text-xs text-wc-muted mb-6">Horarios en tiempo de México (UTC-6)</p> ${matchesToday.length === 0 && matchesWeek.length === 0 ? renderTemplate`<div class="card p-8 text-center text-wc-muted"> <i class="ph ph-broadcast" style="font-size:3rem"></i> <p class="mt-3">No hay partidos disponibles en este momento.</p> <p class="text-sm mt-2">Los datos se obtienen de la API publica de ESPN.</p> </div>` : renderTemplate`<div class="space-y-8">  ${matchesToday.length > 0 && renderTemplate`<div> <div class="flex items-center gap-2 mb-4"> <span class="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full bg-wc-gold/20 border border-wc-gold/40 text-wc-gold"> <i class="ph-fill ph-circle text-[8px] animate-pulse"></i> HOY
</span> </div> <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"> ${matchesToday.map((event) => renderTemplate`${renderComponent($$result2, "MatchCard", $$MatchCard, { "event": event })}`)} </div> </div>`}  ${matchesWeek.length > 0 && renderTemplate`<div> <div class="flex items-center gap-2 mb-4"> <span class="text-sm font-semibold text-wc-muted flex items-center gap-1.5"> <i class="ph ph-calendar-blank"></i> ${previewMode ? "Partidos de apertura — 11 jun" : matchesToday.length > 0 ? "Esta semana" : "Próximos partidos"} </span> </div> <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 opacity-90"> ${matchesWeek.map((event) => renderTemplate`${renderComponent($$result2, "MatchCard", $$MatchCard, { "event": event })}`)} </div> </div>`} </div>`} </section>`} <!-- Tab: Contendientes --> ${tab === "contendientes" && renderTemplate`<section> <h2 class="font-display text-3xl text-wc-gold mb-6 tracking-wide">CONTENDIENTES</h2> ${participants.length === 0 ? renderTemplate`<div class="card p-8 text-center text-wc-muted">La quiniela aún no tiene participantes.</div>` : renderTemplate`<div class="grid grid-cols-1 sm:grid-cols-2 gap-4"> ${participants.map((p) => {
    const pTeams = assignments.filter((a) => a.participant_id === p.id).map((a) => ({ ...a, team: getTeam(a.team_code) })).filter((a) => a.team);
    const fav = pTeams.filter((a) => a.team?.tier === "favorito");
    const cre = pTeams.filter((a) => a.team?.tier === "creyente");
    const mal = pTeams.filter((a) => a.team?.tier === "maleta");
    return renderTemplate`<div class="card p-5"> <div class="flex items-center gap-3 mb-4"> <div class="w-10 h-10 rounded-full bg-wc-blue flex items-center justify-center font-display text-xl text-wc-gold"> ${p.name[0].toUpperCase()} </div> <div> <h3 class="font-semibold">${p.name}</h3> <p class="text-xs text-wc-muted">${pTeams.length} equipos</p> </div> </div> ${fav.length > 0 && renderTemplate`<div class="mb-3"> <p class="text-xs text-wc-gold mb-1.5 flex items-center gap-1"><i class="ph-fill ph-star"></i> Favoritos</p> <div class="flex flex-wrap gap-1.5"> ${fav.map((a) => renderTemplate`<span class="team-badge text-xs"> ${a.team.flag} ${a.team.name} ${a.share_percentage < 100 && renderTemplate`<span class="text-wc-gold"> ${a.share_percentage.toFixed(0)}%</span>`} </span>`)} </div> </div>`} ${cre.length > 0 && renderTemplate`<div class="mb-3"> <p class="text-xs text-blue-400 mb-1.5 flex items-center gap-1"><i class="ph-fill ph-fire"></i> Creyentes</p> <div class="flex flex-wrap gap-1.5"> ${cre.map((a) => renderTemplate`<span class="team-badge text-xs"> ${a.team.flag} ${a.team.name} ${a.share_percentage < 100 && renderTemplate`<span class="text-wc-gold"> ${a.share_percentage.toFixed(0)}%</span>`} </span>`)} </div> </div>`} ${mal.length > 0 && renderTemplate`<div> <p class="text-xs text-wc-muted mb-1.5 flex items-center gap-1"><i class="ph ph-briefcase"></i> Maletas</p> <div class="flex flex-wrap gap-1.5"> ${mal.map((a) => renderTemplate`<span class="team-badge text-xs opacity-70"> ${a.team.flag} ${a.team.name} ${a.share_percentage < 100 && renderTemplate`<span class="text-wc-gold"> ${a.share_percentage.toFixed(0)}%</span>`} </span>`)} </div> </div>`} ${pTeams.length === 0 && renderTemplate`<p class="text-xs text-wc-muted">Equipos pendientes de asignar</p>`} </div>`;
  })} </div>`} </section>`} <!-- Tab: Equipos --> ${tab === "equipos" && renderTemplate`${renderComponent($$result2, "TeamsTab", $$TeamsTab, {})}`} <!-- Tab: Reclamos --> ${tab === "reclamos" && isParticipant && q.status === "draft" && renderTemplate`<section> <!-- Title + tooltip --> <div class="flex items-start gap-3 mb-2"> <h2 class="font-display text-3xl text-wc-gold tracking-wide">RECLAMAR EQUIPOS</h2> <div class="relative mt-1" id="claim-info-wrap"> <button id="claim-info-btn" class="text-wc-muted hover:text-wc-gold transition-colors focus:outline-none" aria-label="¿Cómo funciona?" type="button"> <i class="ph ph-info text-2xl"></i> </button> <div id="claim-info-tooltip" class="hidden fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[min(20rem,calc(100vw-2rem))] card p-4 text-xs text-wc-muted border border-wc-blue/40 shadow-2xl"> <p class="font-semibold text-white mb-2 flex items-center gap-1.5"> <i class="ph-fill ph-info text-wc-gold"></i> ¿Cómo funcionan los reclamos?
</p> <p class="leading-relaxed">
Al reclamar un equipo, tienes que pagar el precio proporcional establecido.
                Todos pueden reclamar el mismo equipo — esto <strong class="text-white">disminuye el costo por reclamo</strong> entre
                el número de contendientes. Si el equipo reclamado gana, <strong class="text-white">la bolsa se divide</strong> entre
                los contendientes que reclamaron al equipo.
</p> <button id="claim-info-close" class="mt-3 text-wc-gold underline underline-offset-2" type="button">Cerrar</button> </div> </div> </div> <p class="text-sm text-wc-muted mb-6">
Equipos disponibles. Reclámalos pagando el extra — si varios lo reclaman, el costo y la bolsa se dividen.
</p> ${leftover.length === 0 ? renderTemplate`<div class="card p-8 text-center text-wc-muted">
No hay equipos disponibles para reclamar.
</div>` : renderTemplate`<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"> ${leftover.map((code) => {
    const team = getTeam(code);
    if (!team) return null;
    const cfg = TIER_CONFIG[team.tier];
    const teamClaims = claims.filter((c) => c.team_code === code);
    const isClaimed = myClaims.includes(code);
    const claimerCount = teamClaims.length;
    const isFullyClaimed = claimerCount >= participants.length;
    const myCurrentPrice = isClaimed ? Math.ceil(cfg.extraPrice / claimerCount) : Math.ceil(cfg.extraPrice / (claimerCount + 1));
    const priceDropped = claimerCount > 0 && !isClaimed;
    const claimerNames = teamClaims.map((c) => c.participant_name).join(", ");
    return renderTemplate`<div${addAttribute([
      "card p-4 border transition-all",
      isClaimed ? "border-wc-gold/50 bg-wc-gold/5" : isFullyClaimed ? "border-wc-border opacity-60" : "border-wc-border hover:border-wc-blue/50"
    ], "class:list")}> <div class="flex items-center gap-3 mb-3"> <span class="text-3xl">${team.flag}</span> <div class="flex-1"> <h4 class="font-semibold">${team.name}</h4> <p class="text-xs text-wc-muted flex items-center gap-1"> <i${addAttribute(["ph", cfg.icon, "text-xs"], "class:list")}></i> ${cfg.label} </p> </div> <div class="text-right"> ${priceDropped && renderTemplate`<p class="text-[10px] text-wc-muted line-through">$${cfg.extraPrice}</p>`} <p${addAttribute(["font-bold text-lg", isClaimed ? "text-wc-gold" : priceDropped ? "text-green-400" : "text-wc-gold"], "class:list")}>
$${myCurrentPrice} </p> <p class="text-[10px] text-wc-muted">MXN</p> </div> </div> ${claimerCount > 0 && renderTemplate`<p class="text-xs text-wc-muted mb-2 flex items-center gap-1"> <i class="ph ph-users text-xs"></i> ${claimerCount} reclamo${claimerCount > 1 ? "s" : ""} · ${claimerNames} </p>`} ${isFullyClaimed && !isClaimed ? renderTemplate`<div class="w-full py-2 rounded-lg text-sm text-center text-wc-muted border border-wc-border bg-wc-dark/50"> <i class="ph ph-lock-simple"></i> Todos reclamaron este equipo
</div>` : renderTemplate`<form method="POST"> <input type="hidden" name="team_code"${addAttribute(code, "value")}> <input type="hidden" name="action"${addAttribute(isClaimed ? "unclaim" : "claim", "value")}> <button type="submit"${addAttribute([
      "w-full py-2 rounded-lg text-sm font-medium transition-colors",
      isClaimed ? "bg-wc-red/20 hover:bg-wc-red/40 text-wc-red border border-wc-red/30" : "btn-gold"
    ], "class:list")}> ${isClaimed ? renderTemplate`<span class="flex items-center justify-center gap-1"><i class="ph ph-x"></i> Quitar reclamo</span>` : renderTemplate`<span class="flex items-center justify-center gap-1"><i class="ph-bold ph-plus"></i> Reclamar · $${myCurrentPrice} MXN</span>`} </button> </form>`} </div>`;
  })} </div>`} </section>`} </div> ` }));
}, "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/pages/quiniela/[slug].astro", void 0);
const $$file = "/Users/asaf/Projects/Fulbito-Quiniela-Amistosa/src/pages/quiniela/[slug].astro";
const $$url = "/quiniela/quiniela/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
