import { k as getAdminByUsername } from '../../../chunks/db_Y1fRCVEg.mjs';
import { v as verifyPassword, f as startSession, s as sessionCookie } from '../../../chunks/auth_CdljRRhG.mjs';
export { renderers } from '../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  const form = await request.formData();
  const username = form.get("username")?.trim();
  const password = form.get("password");
  if (!username || !password) {
    return new Response(null, { status: 302, headers: { Location: `${base}admin?error=1` } });
  }
  const admin = await getAdminByUsername(username);
  if (!admin) {
    return new Response(null, { status: 302, headers: { Location: `${base}admin?error=1` } });
  }
  const valid = await verifyPassword(password, admin.password_hash);
  if (!valid) {
    return new Response(null, { status: 302, headers: { Location: `${base}admin?error=1` } });
  }
  const token = await startSession(admin.id);
  return new Response(null, {
    status: 302,
    headers: {
      Location: `${base}admin/dashboard`,
      "Set-Cookie": sessionCookie(token)
    }
  });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
