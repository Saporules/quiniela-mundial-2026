import { d as getSessionToken, e as endSession, c as clearSessionCookie } from '../../../chunks/auth_CdljRRhG.mjs';
export { renderers } from '../../../renderers.mjs';

const POST = async ({ request }) => {
  const token = getSessionToken(request);
  if (token) await endSession(token);
  return new Response(null, {
    status: 302,
    headers: {
      Location: `${"/quiniela/"}admin`,
      "Set-Cookie": clearSessionCookie()
    }
  });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
