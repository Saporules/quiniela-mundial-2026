import { d as countAdmins, e as createAdmin } from '../../../chunks/db_Y1fRCVEg.mjs';
import { h as hashPassword, f as startSession, s as sessionCookie } from '../../../chunks/auth_CdljRRhG.mjs';
export { renderers } from '../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  if (await countAdmins() > 0) {
    return new Response(null, { status: 302, headers: { Location: `${base}admin` } });
  }
  const form = await request.formData();
  const username = form.get("username")?.trim();
  const password = form.get("password");
  const confirm = form.get("confirm");
  if (!username || !password || password !== confirm || password.length < 8) {
    return new Response(null, { status: 302, headers: { Location: `${base}admin/setup?error=1` } });
  }
  try {
    const hash = await hashPassword(password);
    const adminId = await createAdmin(username, hash);
    const token = await startSession(adminId);
    return new Response(null, {
      status: 302,
      headers: {
        Location: `${base}admin/dashboard`,
        "Set-Cookie": sessionCookie(token)
      }
    });
  } catch {
    return new Response(null, { status: 302, headers: { Location: `${base}admin/setup?error=1` } });
  }
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
