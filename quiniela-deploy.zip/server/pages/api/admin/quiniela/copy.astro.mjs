import { b as getAdminFromRequest, a as generateSlug, g as generateAccessToken } from '../../../../chunks/auth_CdljRRhG.mjs';
import { r as getQuinielById, q as getParticipants, s as getQuinielBySlug, f as createQuiniela, b as addParticipant } from '../../../../chunks/db_Y1fRCVEg.mjs';
export { renderers } from '../../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  const admin = await getAdminFromRequest(request);
  if (!admin) return new Response(null, { status: 302, headers: { Location: `${base}admin` } });
  const form = await request.formData();
  const quinielaId = Number(form.get("quiniela_id"));
  const q = await getQuinielById(quinielaId);
  if (!q) return new Response(null, { status: 302, headers: { Location: `${base}admin/dashboard` } });
  const participants = await getParticipants(quinielaId);
  let slug = generateSlug();
  let attempts = 0;
  while (await getQuinielBySlug(slug) && attempts < 10) {
    slug = generateSlug();
    attempts++;
  }
  const newId = await createQuiniela({
    slug,
    name: `${q.name} (copia)`,
    tournament: q.tournament,
    mode: q.mode,
    basePrice: q.base_price,
    favoritoPrice: q.favorito_price,
    creyentePrice: q.creyente_price,
    maletePrice: q.malete_price
  });
  for (const p of participants) {
    await addParticipant({
      quinielaId: newId,
      name: p.name,
      email: p.email,
      accessToken: generateAccessToken()
    });
  }
  return new Response(null, { status: 302, headers: { Location: `${base}admin/quiniela/${newId}` } });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
