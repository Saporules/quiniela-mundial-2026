import { b as getAdminFromRequest } from '../../../../chunks/auth_CdljRRhG.mjs';
import { r as getQuinielById } from '../../../../chunks/db_Y1fRCVEg.mjs';
import { r as resolveClaims } from '../../../../chunks/assignment_C28mivLj.mjs';
export { renderers } from '../../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  const admin = await getAdminFromRequest(request);
  if (!admin) return new Response(null, { status: 302, headers: { Location: `${base}admin` } });
  const form = await request.formData();
  const quinielaId = Number(form.get("quiniela_id"));
  const q = await getQuinielById(quinielaId);
  if (!q || q.status !== "draft") {
    return new Response(null, { status: 302, headers: { Location: `${base}admin/quiniela/${quinielaId}` } });
  }
  try {
    await resolveClaims(quinielaId, {
      favoritoPrice: q.favorito_price,
      creyentePrice: q.creyente_price,
      maletePrice: q.malete_price
    });
  } catch (err) {
    console.error("Error resolving claims:", err);
  }
  return new Response(null, { status: 302, headers: { Location: `${base}admin/quiniela/${quinielaId}` } });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
