import { b as getAdminFromRequest, g as generateAccessToken } from '../../../../chunks/auth_CdljRRhG.mjs';
import { r as getQuinielById, b as addParticipant, h as deleteParticipant } from '../../../../chunks/db_Y1fRCVEg.mjs';
export { renderers } from '../../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  const admin = await getAdminFromRequest(request);
  if (!admin) return new Response(null, { status: 302, headers: { Location: `${base}admin` } });
  const form = await request.formData();
  const action = form.get("action");
  const quinielaId = Number(form.get("quiniela_id"));
  const q = await getQuinielById(quinielaId);
  if (!q) return new Response(null, { status: 302, headers: { Location: `${base}admin/dashboard` } });
  if (q.status !== "setup") return new Response(null, { status: 302, headers: { Location: `${base}admin/quiniela/${quinielaId}` } });
  if (action === "add") {
    const name = form.get("name")?.trim();
    const email = form.get("email")?.trim().toLowerCase();
    if (name && email) {
      await addParticipant({ quinielaId, name, email, accessToken: generateAccessToken() });
    }
  } else if (action === "delete") {
    const participantId = Number(form.get("participant_id"));
    if (participantId) await deleteParticipant(participantId);
  }
  return new Response(null, { status: 302, headers: { Location: `${base}admin/quiniela/${quinielaId}` } });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
