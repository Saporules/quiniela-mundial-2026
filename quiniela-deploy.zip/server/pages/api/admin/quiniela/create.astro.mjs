import { b as getAdminFromRequest, a as generateSlug } from '../../../../chunks/auth_CdljRRhG.mjs';
import { s as getQuinielBySlug, f as createQuiniela } from '../../../../chunks/db_Y1fRCVEg.mjs';
export { renderers } from '../../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  const admin = await getAdminFromRequest(request);
  if (!admin) return new Response(null, { status: 302, headers: { Location: `${base}admin` } });
  const form = await request.formData();
  const name = form.get("name")?.trim();
  const tournament = form.get("tournament") ?? "world_cup_2026";
  const mode = form.get("mode") === "full_random" ? "full_random" : "reclamo";
  const basePrice = Number(form.get("base_price")) || 300;
  const favoritoPrice = Number(form.get("favorito_price")) || 150;
  const creyentePrice = Number(form.get("creyente_price")) || 100;
  const maletePrice = Number(form.get("malete_price")) || 50;
  if (!name) return new Response(null, { status: 302, headers: { Location: `${base}admin/dashboard` } });
  let slug = generateSlug();
  let attempts = 0;
  while (await getQuinielBySlug(slug) && attempts < 10) {
    slug = generateSlug();
    attempts++;
  }
  const id = await createQuiniela({ slug, name, tournament, mode, basePrice, favoritoPrice, creyentePrice, maletePrice });
  return new Response(null, { status: 302, headers: { Location: `${base}admin/quiniela/${id}` } });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
