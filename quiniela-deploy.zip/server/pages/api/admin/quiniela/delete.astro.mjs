import { b as getAdminFromRequest } from '../../../../chunks/auth_CdljRRhG.mjs';
import { r as getQuinielById, i as deleteQuiniela } from '../../../../chunks/db_Y1fRCVEg.mjs';
export { renderers } from '../../../../renderers.mjs';

const POST = async ({ request }) => {
  const base = "/quiniela/";
  const admin = await getAdminFromRequest(request);
  if (!admin) return new Response(null, { status: 302, headers: { Location: `${base}admin` } });
  const form = await request.formData();
  const quinielaId = Number(form.get("quiniela_id"));
  const q = await getQuinielById(quinielaId);
  if (!q) return new Response(null, { status: 302, headers: { Location: `${base}admin/dashboard` } });
  await deleteQuiniela(quinielaId);
  return new Response(null, { status: 302, headers: { Location: `${base}admin/dashboard` } });
};

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
