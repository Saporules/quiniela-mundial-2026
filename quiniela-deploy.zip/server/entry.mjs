import { renderers } from './renderers.mjs';
import { c as createExports, s as serverEntrypointModule } from './chunks/_@astrojs-ssr-adapter_xRqqltWK.mjs';
import { manifest } from './manifest_6Fmrhj-R.mjs';

const serverIslandMap = new Map();;

const _page0 = () => import('./pages/_image.astro.mjs');
const _page1 = () => import('./pages/admin/dashboard.astro.mjs');
const _page2 = () => import('./pages/admin/quiniela/_id_.astro.mjs');
const _page3 = () => import('./pages/admin/setup.astro.mjs');
const _page4 = () => import('./pages/admin.astro.mjs');
const _page5 = () => import('./pages/api/admin/quiniela/assign.astro.mjs');
const _page6 = () => import('./pages/api/admin/quiniela/copy.astro.mjs');
const _page7 = () => import('./pages/api/admin/quiniela/create.astro.mjs');
const _page8 = () => import('./pages/api/admin/quiniela/delete.astro.mjs');
const _page9 = () => import('./pages/api/admin/quiniela/participant.astro.mjs');
const _page10 = () => import('./pages/api/admin/quiniela/reset.astro.mjs');
const _page11 = () => import('./pages/api/admin/quiniela/resolve-claims.astro.mjs');
const _page12 = () => import('./pages/api/admin/setup.astro.mjs');
const _page13 = () => import('./pages/api/auth/login.astro.mjs');
const _page14 = () => import('./pages/api/auth/logout.astro.mjs');
const _page15 = () => import('./pages/quiniela/_slug_.astro.mjs');
const _page16 = () => import('./pages/index.astro.mjs');
const pageMap = new Map([
    ["node_modules/astro/dist/assets/endpoint/node.js", _page0],
    ["src/pages/admin/dashboard.astro", _page1],
    ["src/pages/admin/quiniela/[id].astro", _page2],
    ["src/pages/admin/setup.astro", _page3],
    ["src/pages/admin/index.astro", _page4],
    ["src/pages/api/admin/quiniela/assign.ts", _page5],
    ["src/pages/api/admin/quiniela/copy.ts", _page6],
    ["src/pages/api/admin/quiniela/create.ts", _page7],
    ["src/pages/api/admin/quiniela/delete.ts", _page8],
    ["src/pages/api/admin/quiniela/participant.ts", _page9],
    ["src/pages/api/admin/quiniela/reset.ts", _page10],
    ["src/pages/api/admin/quiniela/resolve-claims.ts", _page11],
    ["src/pages/api/admin/setup.ts", _page12],
    ["src/pages/api/auth/login.ts", _page13],
    ["src/pages/api/auth/logout.ts", _page14],
    ["src/pages/quiniela/[slug].astro", _page15],
    ["src/pages/index.astro", _page16]
]);

const _manifest = Object.assign(manifest, {
    pageMap,
    serverIslandMap,
    renderers,
    actions: () => import('./noop-entrypoint.mjs'),
    middleware: () => import('./_noop-middleware.mjs')
});
const _args = {
    "mode": "standalone",
    "client": "file:///Users/asaf/Projects/Fulbito-Quiniela-Amistosa/dist/client/",
    "server": "file:///Users/asaf/Projects/Fulbito-Quiniela-Amistosa/dist/server/",
    "host": false,
    "port": 4321,
    "assets": "_astro",
    "experimentalStaticHeaders": false
};
const _exports = createExports(_manifest, _args);
const handler = _exports['handler'];
const startServer = _exports['startServer'];
const options = _exports['options'];
const _start = 'start';
if (Object.prototype.hasOwnProperty.call(serverEntrypointModule, _start)) {
	serverEntrypointModule[_start](_manifest, _args);
}

export { handler, options, pageMap, startServer };
